package com.classselector;

import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Tela de seleção de classes (visual em PickScreen). */
public class ClassSelectScreen extends PickScreen {
    public ClassSelectScreen(boolean forced) {
        super(Component.literal("Classes"), "Seleção de Classe", "Selecionar Classe", forced);
    }

    @Override
    protected List<Entry> entries() {
        List<Entry> l = new ArrayList<>();
        for (ClassDef c : ClientState.classes)
            l.add(new Entry(c.id, c.name, c.iconStack(), c.description, "Habilidades", c.abilities, false, "Itens", c.items));
        return l;
    }

    @Override
    protected void choose(String id) {
        Net.CH.sendToServer(new Net.Select(id));
        minecraft.setScreen(null);
    }

    @Override
    protected void edit(String id) {
        ClassDef found = null;
        if (id != null) for (ClassDef c : ClientState.classes) if (c.id.equals(id)) found = c;
        minecraft.setScreen(new ClassEditScreen(this, found));
    }

    @Override
    protected String emptyText() { return "Nenhuma classe criada"; }
}
