package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class Net {
    private static final String V = "3";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ClassSelectorMod.MODID, "main"), () -> V, V::equals, V::equals);

    public static void register() {
        int i = 0;
        CH.registerMessage(i++, Sync.class, Sync::enc, Sync::dec, Sync::handle);
        CH.registerMessage(i++, Select.class, Select::enc, Select::dec, Select::handle);
        CH.registerMessage(i++, Save.class, Save::enc, Save::dec, Save::handle);
        CH.registerMessage(i++, Delete.class, Delete::enc, Delete::dec, Delete::handle);
        CH.registerMessage(i++, EditItems.class, EditItems::enc, EditItems::dec, EditItems::handle);
        CH.registerMessage(i++, SelectRace.class, SelectRace::enc, SelectRace::dec, SelectRace::handle);
        CH.registerMessage(i++, SaveRace.class, SaveRace::enc, SaveRace::dec, SaveRace::handle);
        CH.registerMessage(i++, DeleteRace.class, DeleteRace::enc, DeleteRace::dec, DeleteRace::handle);
    }

    /** Qual tela o jogador precisa ver agora: 4 = raça, 2 = classe, 0 = nenhuma. */
    public static int initialOpen(ServerPlayer p) {
        String rid = p.getPersistentData().getString(ClassSelectorMod.KEY_RACE);
        RaceData rd = RaceData.get(p.server);
        if ((rid.isEmpty() || !rd.races.containsKey(rid)) && !rd.races.isEmpty()) return 4;
        boolean classChosen = !p.getPersistentData().getString(ClassSelectorMod.KEY).isEmpty();
        if (!classChosen && !ClassData.get(p.server).classes.isEmpty()) return 2;
        return 0;
    }

    public static void sendSync(ServerPlayer p, int open) {
        ListTag cl = new ListTag();
        for (ClassDef c : ClassData.get(p.server).classes.values()) cl.add(c.save());
        ListTag rl = new ListTag();
        for (RaceDef r : RaceData.get(p.server).races.values()) rl.add(r.save());
        CompoundTag t = new CompoundTag();
        t.put("classes", cl);
        t.put("races", rl);
        String myRace = p.getPersistentData().getString(ClassSelectorMod.KEY_RACE);
        CH.send(PacketDistributor.PLAYER.with(() -> p), new Sync(open, p.hasPermissions(2), myRace, t));
        RestrictManager.sync(p);
    }

    /** Reenvia os dados a todos e reaplica os bônus de raça (caso o OP tenha editado). */
    public static void syncAll(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            RaceApplier.refresh(p);
            sendSync(p, 0);
        }
    }

    // ---------- servidor -> cliente ----------
    public record Sync(int open, boolean op, String myRace, CompoundTag data) {
        static void enc(Sync m, FriendlyByteBuf b) {
            b.writeVarInt(m.open); b.writeBoolean(m.op); b.writeUtf(m.myRace, 64); b.writeNbt(m.data);
        }
        static Sync dec(FriendlyByteBuf b) {
            int open = b.readVarInt();
            boolean op = b.readBoolean();
            String race = b.readUtf(64);
            return new Sync(open, op, race, b.readNbt());
        }
        static void handle(Sync m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientHooks.sync(m.open, m.op, m.myRace, m.data)));
            c.get().setPacketHandled(true);
        }
    }

    // ---------- classes ----------
    public record Select(String id) {
        static void enc(Select m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static Select dec(FriendlyByteBuf b) { return new Select(b.readUtf(64)); }
        static void handle(Select m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null) return;
                ClassDef def = ClassData.get(p.server).classes.get(m.id);
                if (def == null) return;
                boolean chosen = !p.getPersistentData().getString(ClassSelectorMod.KEY).isEmpty();
                if (chosen && !p.hasPermissions(2)) return;
                p.getPersistentData().putString(ClassSelectorMod.KEY, def.id);
                RestrictManager.sync(p);
                QuestManager.sync(p, false); // abas por classe mudam
                SkillManager.sync(p, false);
                for (ItemStack s : def.items) {
                    ItemStack copy = s.copy();
                    if (!p.getInventory().add(copy)) p.drop(copy, false);
                }
            });
            c.get().setPacketHandled(true);
        }
    }

    public record Save(CompoundTag def) {
        static void enc(Save m, FriendlyByteBuf b) { b.writeNbt(m.def); }
        static Save dec(FriendlyByteBuf b) { return new Save(b.readNbt()); }
        static void handle(Save m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                ClassDef in = ClassDef.load(m.def);
                in.id = ClassDef.sanitize(in.id);
                if (in.id.isEmpty() || in.name.isBlank()) return;
                if (in.name.length() > 40) in.name = in.name.substring(0, 40);
                if (in.description.length() > 300) in.description = in.description.substring(0, 300);
                ClassData data = ClassData.get(p.server);
                ClassDef old = data.classes.get(in.id);
                in.items = old != null ? old.items : new java.util.ArrayList<>();
                data.classes.put(in.id, in);
                data.setDirty();
                syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record Delete(String id) {
        static void enc(Delete m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static Delete dec(FriendlyByteBuf b) { return new Delete(b.readUtf(64)); }
        static void handle(Delete m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                ClassData data = ClassData.get(p.server);
                if (data.classes.remove(m.id) != null) {
                    data.setDirty();
                    // abas/árvores presas a essa classe continuam restritas (só OP vê) até o OP reatribuir;
                    // assim apagar a classe não vaza conteúdo exclusivo para todo mundo.
                    syncAll(p.server);
                }
            });
            c.get().setPacketHandled(true);
        }
    }

    public record EditItems(String id) {
        static void enc(EditItems m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static EditItems dec(FriendlyByteBuf b) { return new EditItems(b.readUtf(64)); }
        static void handle(EditItems m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                ClassDef def = ClassData.get(p.server).classes.get(m.id);
                if (def != null) ClassItemsMenu.open(p, def);
            });
            c.get().setPacketHandled(true);
        }
    }

    // ---------- raças ----------
    public record SelectRace(String id) {
        static void enc(SelectRace m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static SelectRace dec(FriendlyByteBuf b) { return new SelectRace(b.readUtf(64)); }
        static void handle(SelectRace m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null) return;
                RaceDef def = RaceData.get(p.server).races.get(m.id);
                if (def == null) return;
                String cur = p.getPersistentData().getString(ClassSelectorMod.KEY_RACE);
                boolean chosen = !cur.isEmpty() && RaceData.get(p.server).races.containsKey(cur);
                if (chosen && !p.hasPermissions(2)) return; // só OP pode trocar de raça
                p.getPersistentData().putString(ClassSelectorMod.KEY_RACE, def.id);
                RaceApplier.refresh(p);
                // depois da raça vem a classe (se ainda não escolheu)
                sendSync(p, initialOpen(p) == 2 ? 2 : 0);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record SaveRace(CompoundTag def) {
        static void enc(SaveRace m, FriendlyByteBuf b) { b.writeNbt(m.def); }
        static SaveRace dec(FriendlyByteBuf b) { return new SaveRace(b.readNbt()); }
        static void handle(SaveRace m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                RaceDef in = RaceDef.load(m.def);
                in.id = ClassDef.sanitize(in.id);
                if (in.id.isEmpty() || in.name.isBlank()) return;
                if (in.name.length() > 40) in.name = in.name.substring(0, 40);
                if (in.description.length() > 300) in.description = in.description.substring(0, 300);
                in.clampValues();
                RaceData data = RaceData.get(p.server);
                data.races.put(in.id, in);
                data.setDirty();
                syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record DeleteRace(String id) {
        static void enc(DeleteRace m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static DeleteRace dec(FriendlyByteBuf b) { return new DeleteRace(b.readUtf(64)); }
        static void handle(DeleteRace m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                RaceData data = RaceData.get(p.server);
                if (data.races.remove(m.id) == null) return;
                data.setDirty();
                // quem tinha essa raça escolhe de novo
                for (ServerPlayer t : p.server.getPlayerList().getPlayers()) {
                    if (m.id.equals(t.getPersistentData().getString(ClassSelectorMod.KEY_RACE))) {
                        t.getPersistentData().remove(ClassSelectorMod.KEY_RACE);
                        RaceApplier.refresh(t);
                        sendSync(t, initialOpen(t));
                    }
                }
                syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }
}
