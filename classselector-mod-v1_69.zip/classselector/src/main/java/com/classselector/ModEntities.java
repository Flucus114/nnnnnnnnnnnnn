package com.classselector;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ClassSelectorMod.MODID);

    /** Boss: Soberano Cósmico. Spawn via ovo de spawn ou /summon classselector:cosmic_sovereign */
    public static final RegistryObject<EntityType<CosmicBoss>> COSMIC_BOSS = ENTITIES.register("cosmic_sovereign",
            () -> EntityType.Builder.of(CosmicBoss::new, MobCategory.MONSTER)
                    .sized(CosmicBoss.WIDTH, CosmicBoss.HEIGHT)
                    .fireImmune()
                    .clientTrackingRange(10)
                    .build("cosmic_sovereign"));

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent e) {
        e.put(COSMIC_BOSS.get(), CosmicBoss.createAttributes().build());
    }
}
