package com.classselector;

import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public class QuestEvents {
    private static int tick = 0;

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        QuestManager.checkItems(p);
        QuestManager.sync(p, false);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s == null) return;
        tick++;
        if (tick % 20 == 0) {
            for (ServerPlayer p : s.getPlayerList().getPlayers()) QuestManager.checkItems(p);
        }
        if (tick % 10 == 0 && !QuestManager.pending.isEmpty()) {
            for (UUID u : new ArrayList<>(QuestManager.pending)) {
                ServerPlayer p = s.getPlayerList().getPlayer(u);
                if (p != null) QuestManager.sync(p, false);
            }
            QuestManager.pending.clear();
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer killer)) return;
        LivingEntity victim = e.getEntity();
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(victim.getType());
        if (id != null) QuestManager.add(killer, QuestType.BOSS, id.toString(), 1);
        if (victim instanceof ServerPlayer && victim != killer) QuestManager.add(killer, QuestType.PLAYER, "", 1);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p) || p instanceof FakePlayer) return;
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(e.getState().getBlock());
        if (id != null) QuestManager.add(p, QuestType.BLOCK, id.toString(), 1);
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("quests")
                // /quests -> abre a tela de quests (qualquer jogador)
                .executes(c -> {
                    QuestManager.sync(c.getSource().getPlayerOrException(), true);
                    return 1;
                })
                // /quests reset <jogador> -> apaga o progresso (OP)
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "player");
                            PlayerQuestData pd = PlayerQuestData.get(t.server);
                            pd.players.remove(t.getUUID());
                            pd.setDirty();
                            QuestManager.sync(t, false);
                            c.getSource().sendSuccess(() -> Component.literal(
                                    "Progresso de quests de " + t.getName().getString() + " apagado."), true);
                            return 1;
                        }))));
    }
}
