package com.classselector;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/** Cria, edita ou apaga uma aba de quests (só OP). */
public class QuestTabEditScreen extends Screen {
    private final Screen parent;
    private final QuestTabDef orig;
    private final boolean skills; // true = árvore de habilidades
    private EditBox id, name, icon;
    private String classId;
    private Button classBtn;

    public QuestTabEditScreen(Screen parent, QuestTabDef orig) { this(parent, orig, false); }

    public QuestTabEditScreen(Screen parent, QuestTabDef orig, boolean skills) {
        super(Component.literal(skills ? (orig == null ? "Nova árvore" : "Editar árvore")
                : (orig == null ? "Nova aba" : "Editar aba")));
        this.skills = skills;
        this.parent = parent;
        this.orig = orig;
        this.classId = orig == null ? "" : orig.classId;
    }

    private int topY() { return Math.max(10, height / 2 - 95); }

    private String className(String cid) {
        if (cid.isEmpty()) return "Todas as classes";
        for (ClassDef c : ClientState.classes) if (c.id.equals(cid)) return c.name;
        return cid + " (apagada)";
    }

    /** Passa para a próxima classe da lista (a primeira opção é "Todas"). */
    private void cycleClass() {
        java.util.List<String> opts = new java.util.ArrayList<>();
        opts.add("");
        for (ClassDef c : ClientState.classes) opts.add(c.id);
        int i = opts.indexOf(classId);
        classId = opts.get((i + 1) % opts.size());
        classBtn.setMessage(Component.literal("Só a classe: " + className(classId)));
    }

    private EditBox box(int x, int y, int w, String val) {
        EditBox b = new EditBox(font, x, y, w, 18, Component.empty());
        b.setMaxLength(256);
        b.setValue(val);
        addRenderableWidget(b);
        return b;
    }

    @Override
    protected void init() {
        int x = width / 2 - 100, y = topY();
        id = box(x, y + 22, 200, orig == null ? "" : orig.id);
        id.setEditable(orig == null);
        name = box(x, y + 54, 200, orig == null ? "" : orig.name);
        icon = box(x, y + 86, 200, orig == null ? "minecraft:book" : orig.icon);
        addRenderableWidget(Button.builder(Component.literal("Ícone = item na mão"), b -> {
            ItemStack held = minecraft.player.getMainHandItem();
            if (!held.isEmpty()) icon.setValue(ForgeRegistries.ITEMS.getKey(held.getItem()).toString());
        }).bounds(x, y + 108, 200, 20).build());

        classBtn = addRenderableWidget(Button.builder(
                Component.literal("Só a classe: " + className(classId)), b -> cycleClass())
                .bounds(x, y + 132, 200, 20).build());

        int by = y + 160;
        addRenderableWidget(Button.builder(Component.literal("Salvar"), b -> { if (save()) onClose(); })
                .bounds(x, by, 64, 20).build());
        Button del = addRenderableWidget(Button.builder(Component.literal("Excluir"), b -> {
            if (skills) Net.CH.sendToServer(new SkillNet.SDeleteTree(orig.id));
            else Net.CH.sendToServer(new QuestNet.QDeleteTab(orig.id));
            onClose();
        }).bounds(x + 68, by, 64, 20).build());
        del.active = orig != null;
        addRenderableWidget(Button.builder(Component.literal("Voltar"), b -> onClose())
                .bounds(x + 136, by, 64, 20).build());
    }

    private boolean save() {
        String tid = ClassDef.sanitize(id.getValue());
        if (tid.isEmpty() || name.getValue().isBlank()) return false;
        QuestTabDef t = new QuestTabDef();
        t.id = tid;
        t.name = name.getValue().trim();
        t.icon = icon.getValue().trim();
        t.classId = classId;
        if (skills) Net.CH.sendToServer(new SkillNet.SSaveTree(t.save()));
        else Net.CH.sendToServer(new QuestNet.QSaveTab(t.save()));
        return true;
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x = width / 2 - 100, y = topY(), c = 0xFFAAAAAA;
        g.drawCenteredString(font, title, width / 2, y, 0xFFFFFF);
        g.drawString(font, "ID (a-z, 0-9, _)", x, y + 12, c, false);
        g.drawString(font, skills ? "Nome da árvore" : "Nome da aba", x, y + 44, c, false);
        g.drawString(font, "Ícone (id do item)", x, y + 76, c, false);
        if (orig != null)
            g.drawString(font, skills ? "Excluir apaga também as habilidades da árvore" : "Excluir apaga também as quests da aba", x, y + 186, 0xFFFF7777, false);
        super.render(g, mx, my, pt);
    }
}
