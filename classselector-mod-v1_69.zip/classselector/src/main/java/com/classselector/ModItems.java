package com.classselector;

import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ClassSelectorMod.MODID);

    /** Sem receita, sem loot e fora das abas criativas: só via /give até você definir como obter. */
    public static final RegistryObject<Item> COSMIC_EYE = ITEMS.register("cosmic_eye", CosmicEyeItem::new);

    /** Ovo de spawn do boss Soberano Cósmico (aparece na aba de ovos de spawn). */
    public static final RegistryObject<Item> COSMIC_BOSS_EGG = ITEMS.register("cosmic_sovereign_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.COSMIC_BOSS, 0x120A24, 0x9D6BFF, new Item.Properties()));
}
